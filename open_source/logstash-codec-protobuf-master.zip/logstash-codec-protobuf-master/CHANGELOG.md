## 1.2.4
  - Encoder bugfix: avoid pipeline crash if encoding failed.

## 1.2.3
  - Add oneof information to @metadata (protobuf version 3 only).

## 1.2.2
  - Add type conversion feature to encoder

## 1.2.1
  - Keep original data in case of parsing errors

## 1.2.0
  - Autoload all referenced protobuf classes
  - Fix concurrency issue when using multiple pipelines

## 1.1.0
  - Add support for protobuf3

## 1.0.4
  - Update gemspec summary

## 1.0.3
  - Fix some documentation issues

## 1.0.1
 - Speed improvement, better exception handling and code refactoring

## 1.0.0
 - Update to v5.0 API

## 0.1.2
 - First version of this plugin
