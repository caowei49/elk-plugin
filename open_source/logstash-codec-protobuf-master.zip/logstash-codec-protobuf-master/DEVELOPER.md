# logstash-codec-protobuf
No special instructions!
