$LOAD_PATH << File.join(File.dirname(__FILE__), "protocol_buffers", "lib")

load(File.join(File.dirname(__FILE__), "protocol_buffers", "lib", "protocol_buffers.rb"))
