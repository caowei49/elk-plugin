module ProtocolBuffers
  VERSION = "1.6.1"
end
