# logstash-codec-telemetry-gpb
Cisco telemetry codec plugin.
